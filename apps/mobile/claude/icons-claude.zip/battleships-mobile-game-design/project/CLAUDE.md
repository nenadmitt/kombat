# Mobile App UI/UX Design Skill

Source: github.com/ceorkm/mobile-app-ui-design — apply to any mobile app screen, flow, mockup, onboarding, or navigation work.

## Core Philosophy
Great mobile UI is about intentionality, not flashiness. Every pixel, spacing value, and color choice should serve the user. Interfaces should feel smooth, personal, and alive.

Before designing, understand three things:
1. What is the user trying to accomplish? (reduce friction to that goal)
2. How should this make the user feel? (trust, delight, confidence, calm)
3. What's the one thing they should notice first? (visual hierarchy)

## Design Process
**Step 1 — Context:** app type, who the user is (new/returning/power), primary action on the screen, industry conventions.

**Step 2 — Structure first (UX):** map the flow (before/after screens); MVP elements only; primary actions in the **thumb zone** (bottom 1/3); F-pattern reading order; reduce interaction cost (expose content vs. hide behind taps); turn empty states into guided opportunities; pick the right input (sliders for one-time setup, text fields for precise/repeated entry).

**Step 3 — Visual design (UI):**
- Typography: one font family (two max); max 4 sizes & 2 weights; monospace for large numbers (prices/stats); text containers < 600px; hierarchy via size/weight/opacity, not bold-everything.
- Color (60/30/10): 60% neutral base, 30% complementary (text/dark), 10% brand accent (CTAs/key indicators). Opacity variations for text hierarchy (100% headings, 80% body, 60-70% secondary). Accent at 5% opacity for secondary buttons/subtle highlights. Tint shadows to background — never pure gray/black on colored bg. Save strong colors (red) for meaningful moments.
- Spacing (8-pt grid): all spacing divisible by 8 or 4 (8,12,16,24,32,48,64,80,96). Relationship-based (related closer, unrelated further). 2× multiplier between groups. Section padding 80-96px+. Card padding 24-32px.
- Shadows: always soft, never harsh; tint to background; subtle white inner shadows on buttons; faded drop shadows for depth.
- Visual cues: icons/illustrations/images to make info digestible; avatars > initials > generic icons; color-coded categories w/ soft backgrounds + clean isolated images; consistent visual style throughout.

**Step 4 — Emotion (Peak-End Rule):** users remember the peak (most intense) and the end (last impression). Identify & design the peak (micro-animations, celebration, badges, encouraging copy). Design the ending (summary card, progress affirmation, nudge to return). Add emotional feedback loops — success feels rewarding (bounce, glow, sparkle). Celebrate small wins. Motion as a trust signal in high-stakes domains.

**Step 5 — Polish:** subtle glow behind key elements; tiny white inner shadows on primary buttons; 5% accent borders on secondary elements; micro-animations for state changes; tap targets ≥ 44×44pt; check contrast; design error/empty/loading/success states.

## Smart Patterns
- Personalize by stage: new (simple welcome, guided setup), returning (personalized, routine-focused, progress), power (advanced stats, dense info).
- Smarter search: never blank — recent searches, trending, personalized recs.
- Order/status tracking: confident status message; humanize w/ photos/names/quick actions; visual timelines over text date lists.
- Category screens: color-coded cards, soft backgrounds, clean isolated images, layout rhythm.
- Selection over manual input: tappable options w/ icons/emojis; "Other" fallback.

## Anti-Patterns to Avoid
Overused gradients/blur; >4 font sizes or >3 weights; random spacing; hiding key content behind taps/banners; CTAs outside thumb zone; generic empty states; sliders for precise/frequent entry; uniform visual weight (no hierarchy); labels emphasized over values; pure gray/black shadows on colored bg.

## Implementation Notes
Mobile-first at 375px baseline (project uses 390px frames). Modern cards: rounded-2xl / rounded-3xl. backdrop-blur for glassmorphism where appropriate. CSS transitions for micro-interactions.
